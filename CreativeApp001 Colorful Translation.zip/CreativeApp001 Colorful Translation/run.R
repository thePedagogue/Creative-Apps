#Read Library
library(shiny)

#Run Application
runUrl("http://github//thePedagogue//Creative-Apps//CreativeApp001 Colorful Translation.zip")
